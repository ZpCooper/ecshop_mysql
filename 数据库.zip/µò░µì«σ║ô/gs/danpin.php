<?php
/**
 * ECSHOP 首页文件
 * ============================================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * $Author: liubo $
 * $Id: index.php 17217 2011-01-19 06:29:08Z liubo $
*/

define('IN_ECS', true);

require(dirname(__FILE__) . '/includes/init.php');

if ((DEBUG_MODE & 2) != 2)
{
    $smarty->caching = true;
}
$ua = strtolower($_SERVER['HTTP_USER_AGENT']);

$uachar = "/(nokia|sony|ericsson|mot|samsung|sgh|lg|philips|panasonic|alcatel|lenovo|cldc|midp|mobile)/i";

if(($ua == '' || preg_match($uachar, $ua))&& !strpos(strtolower($_SERVER['REQUEST_URI']),'wap'))
{
    $Loaction = 'mobile/';

    if (!empty($Loaction))
    {
        ecs_header("Location: $Loaction\n");

        exit;
    }

}
$str = 'dev';
/*------------------------------------------------------ */
//-- Shopex系统地址转换
/*------------------------------------------------------ */
if (!empty($_GET['gOo']))
{
    if (!empty($_GET['gcat']))
    {
        /* 商品分类。*/
        $Loaction = 'category.php?id=' . $_GET['gcat'];
    }
    elseif (!empty($_GET['acat']))
    {
        /* 文章分类。*/
        $Loaction = 'article_cat.php?id=' . $_GET['acat'];
    }
    elseif (!empty($_GET['goodsid']))
    {
        /* 商品详情。*/
        $Loaction = 'goods.php?id=' . $_GET['goodsid'];
    }
    elseif (!empty($_GET['articleid']))
    {
        /* 文章详情。*/
        $Loaction = 'article.php?id=' . $_GET['articleid'];
    }

    if (!empty($Loaction))
    {
        ecs_header("Location: $Loaction\n");

        exit;
    }
}

//判断是否有ajax请求
$act = !empty($_GET['act']) ? $_GET['act'] : '';
if ($act == 'cat_rec')
{
    $rec_array = array(1 => 'best', 2 => 'new', 3 => 'hot');
    $rec_type = !empty($_REQUEST['rec_type']) ? intval($_REQUEST['rec_type']) : '1';
    $cat_id = !empty($_REQUEST['cid']) ? intval($_REQUEST['cid']) : '0';
    include_once('includes/cls_json.php');
    $json = new JSON;
    $result   = array('error' => 0, 'content' => '', 'type' => $rec_type, 'cat_id' => $cat_id);

    $children = get_children($cat_id);
    $smarty->assign($rec_array[$rec_type] . '_goods',      get_category_recommend_goods($rec_array[$rec_type], $children));    // 推荐商品
    $smarty->assign('cat_rec_sign', 1);
    $result['content'] = $smarty->fetch('library/recommend_' . $rec_array[$rec_type] . '.lbi');
    die($json->encode($result));
}

/*------------------------------------------------------ */
//-- 判断是否存在缓存，如果存在则调用缓存，反之读取相应内容
/*------------------------------------------------------ */
/* 缓存编号 */
$cache_id = sprintf('%X', crc32($_SESSION['user_rank'] . '-' . $_CFG['lang']));

if (!$smarty->is_cached('danpin.dwt', $cache_id))
{
    assign_template();

    $position = assign_ur_here();
    $smarty->assign('page_title',      $position['title']);    // 页面标题
    $smarty->assign('ur_here',         $position['ur_here']);  // 当前位置
    /* meta information */
    $smarty->assign('keywords',        htmlspecialchars($_CFG['shop_keywords']));
    $smarty->assign('description',     htmlspecialchars($_CFG['shop_desc']));
    $smarty->assign('flash_theme',     $_CFG['flash_theme']);  // Flash轮播图片模板
    $smarty->assign('feed_url',        ($_CFG['rewrite'] == 1) ? 'feed.xml' : 'feed.php'); // RSS URL
    $smarty->assign('categories',      get_categories_tree()); // 分类树
    $smarty->assign('helps',           get_shop_help());       // 网店帮助
    $smarty->assign('top_goods',       get_top10(5));           // 总的销售排行
	
	//分类销售排行
    $smarty->assign('get_top10_ttmdxl',   get_top10_fen(78,3));           // 榻榻米垫系列的销售排行
    $smarty->assign('get_top10_sjjxl',get_top10_fen(84,3));           // 升降机系列的销售排行
    $smarty->assign('get_top10_mcxl',    get_top10_fen(87,3));           // 门、窗系列的销售排行
    $smarty->assign('get_top10_zyxl',  get_top10_fen(93,3));           // 桌椅系列的销售排行
    $smarty->assign('get_top10_dxl',  get_top10_fen(98,3));           // 灯系列的销售排行
    $smarty->assign('get_top10_pjxl',  get_top10_fen(103,3));           // 配件系列的销售排行
    $smarty->assign('get_top10_spxl',  get_top10_fen(111,3));           // 饰品系列的销售排行
    $smarty->assign('new_goods',       get_news_goods(5));    // 新品推荐商品	
	//分类推荐商品
	$children = get_children(78);   
    $smarty->assign('best_goods_ttmdxl', get_category_recommend_goods("best", $children)); // 榻榻米垫系列推荐商品
	$children = get_children(84);  
    $smarty->assign('best_goods_sjjxl', get_category_recommend_goods("best", $children)); // 升降机系列推荐商品
	$children = get_children(87);  
    $smarty->assign('best_goods_mcxl', get_category_recommend_goods("best", $children));// 门、窗系列推荐商品
	$children = get_children(93);  
    $smarty->assign('best_goods_zyxl', get_category_recommend_goods("best",$children));// 桌椅系列推荐商品
	$children = get_children(98);  
    $smarty->assign('best_goods_dxl', get_category_recommend_goods("best", $children));// 灯系列推荐商品 
	$children = get_children(103);  	
    $smarty->assign('best_goods_pjxl', get_category_recommend_goods("best", $children));// 配件系列推荐商品 
	$children = get_children(111);  
    $smarty->assign('best_goods_spxl', get_category_recommend_goods("best", $children));// 饰品系列推荐商品
    $smarty->assign('hot_goods',       get_recommend_goods('hot'));     // 热点文章
    $smarty->assign('promotion_goods', get_promote_goods()); // 特价商品
    $smarty->assign('brand_list',      get_brands());
    $smarty->assign('promotion_info',  get_promotion_info()); // 增加一个动态显示所有促销信息的标签栏
    $smarty->assign('invoice_list',    index_get_invoice_query());  // 发货查询
    $smarty->assign('new_articles',    index_get_new_articles());   // 最新文章
    $smarty->assign('youhui_articles', index_get_class_articles(13,5));   // 调取优惠活动文章
    $smarty->assign('xinshou_articles', index_get_class_footer_articles(14,5));   // 调取新手上路文章
    $smarty->assign('liangfang_articles', index_get_class_footer_articles(15,5));   // 调取量房设计文章
    $smarty->assign('anquan_articles', index_get_class_footer_articles(16,5));   // 调取安全保障文章
    $smarty->assign('duxiang_articles', index_get_class_footer_articles(17,5));   // 调取会员独享文章
    $smarty->assign('chuangyi_articles', index_get_class_footer_articles(27,6));   // 调取创意家居文章
    $smarty->assign('kuaixun_articles', index_get_class_footer_articles(28,6));   // 调取缘和快讯文章
    $smarty->assign('wenti_articles', index_get_class_footer_articles(29,3));   // 调取常见问题文章
    $smarty->assign('guanjianci_articles', index_get_class_footer_articles(30,3));   // 调取关键词文章
    $smarty->assign('youqinglianjie', get_link_footer(1));   // 调取友情链接
    $smarty->assign('hezuowangzhan', get_link_footer(2));   // 调取合作网站
    $smarty->assign('rementuijian', get_link_footer(3));   // 调取热门推荐
    $smarty->assign('my_comments', get_comments(3));   // 调取最新评论
    $smarty->assign('new_buy', index_get_recent_buy_query(10));   // 调取最新成交信息
    $smarty->assign('group_buy_goods', index_get_group_buy());      // 团购商品
    $smarty->assign('auction_list',    index_get_auction());        // 拍卖活动
    $smarty->assign('shop_notice',     $_CFG['shop_notice']);       // 商店公告
	$get_index_banner=get_banner(2);
	$index_banner = $get_index_banner[0];
	$smarty->assign('index_banner',   $index_banner);           // 获取网站顶部banner	

	$get_left_banner1=get_banner(46);
	$left_banner1 = $get_left_banner1[0];
	$smarty->assign('left_banner1',   $left_banner1);           // 单品特卖左侧banner图1
	$get_left_banner2=get_banner(47);
	$left_banner2 = $get_left_banner2[0];
	$smarty->assign('left_banner2',   $left_banner2);           // 单品特卖左侧banner图2
	
	$get_danpin_lunbo1=get_banner(43);
	$danpin_lunbo1 = $get_danpin_lunbo1[0];
	$smarty->assign('danpin_lunbo1',   $danpin_lunbo1);           // 获取单品特卖轮播图1	
	$get_danpin_lunbo2=get_banner(44);
	$danpin_lunbo2 = $get_danpin_lunbo2[0];
	$smarty->assign('danpin_lunbo2',   $danpin_lunbo2);           // 获取单品特卖轮播图2	
	$get_danpin_lunbo3=get_banner(45);
	$danpin_lunbo3 = $get_danpin_lunbo3[0];
	$smarty->assign('danpin_lunbo3',   $danpin_lunbo3);           // 获取单品特卖轮播图3 
	
	$get_ttmdxl_simg1=get_banner(48);
	$ttmdxl_simg1 = $get_ttmdxl_simg1[0];
	$smarty->assign('ttmdxl_simg1',   $ttmdxl_simg1);           // 获取 单品特卖一楼榻榻米垫系列小轮播图1
	$get_ttmdxl_simg2=get_banner(49);
	$ttmdxl_simg2 = $get_ttmdxl_simg2[0];
	$smarty->assign('ttmdxl_simg2',   $ttmdxl_simg2);           // 获取 单品特卖一楼榻榻米垫系列小轮播图2
	$get_ttmdxl_simg3=get_banner(50);
	$ttmdxl_simg3 = $get_ttmdxl_simg3[0];
	$smarty->assign('ttmdxl_simg3',   $ttmdxl_simg3);           // 获取 单品特卖一楼榻榻米垫系列小轮播图3	
	$get_ttmdxl_bimg1=get_banner(51);
	$ttmdxl_bimg1 = $get_ttmdxl_bimg1[0];
	$smarty->assign('ttmdxl_bimg1',   $ttmdxl_bimg1);           // 获取 单品特卖一楼榻榻米垫系列大轮播图1
	$get_ttmdxl_bimg2=get_banner(52);
	$ttmdxl_bimg2 = $get_ttmdxl_bimg2[0];
	$smarty->assign('ttmdxl_bimg2',   $ttmdxl_bimg2);           // 获取 单品特卖一楼榻榻米垫系列大轮播图2	
	$get_ttmdxl_bimg3=get_banner(53);
	$ttmdxl_bimg3 = $get_ttmdxl_bimg3[0];
	$smarty->assign('ttmdxl_bimg3',   $ttmdxl_bimg3);           // 获取 单品特卖一楼榻榻米垫系列大轮播图3	

	$get_sjjxl_simg1=get_banner(54);
	$sjjxl_simg1 = $get_sjjxl_simg1[0];
	$smarty->assign('sjjxl_simg1',   $sjjxl_simg1);           // 获取单品特卖二楼升降机系列小轮播图1
	$get_sjjxl_simg2=get_banner(55);
	$sjjxl_simg2 = $get_sjjxl_simg2[0];
	$smarty->assign('sjjxl_simg2',   $sjjxl_simg2);           // 获取单品特卖二楼升降机系列小轮播图2
	$get_sjjxl_simg3=get_banner(56);
	$sjjxl_simg3 = $get_sjjxl_simg3[0];
	$smarty->assign('sjjxl_simg3',   $sjjxl_simg3);           // 获取单品特卖二楼升降机系列小轮播图3	
	$get_sjjxl_bimg1=get_banner(57);
	$sjjxl_bimg1 = $get_sjjxl_bimg1[0];
	$smarty->assign('sjjxl_bimg1',   $sjjxl_bimg1);           // 获取单品特卖二楼升降机系列大轮播图1
	$get_sjjxl_bimg2=get_banner(58);
	$sjjxl_bimg2 = $get_sjjxl_bimg2[0];
	$smarty->assign('sjjxl_bimg2',   $sjjxl_bimg2);           // 获取单品特卖二楼升降机系列大轮播图2	
	$get_sjjxl_bimg3=get_banner(59);
	$sjjxl_bimg3 = $get_sjjxl_bimg3[0];
	$smarty->assign('sjjxl_bimg3',   $sjjxl_bimg3);           // 获取单品特卖二楼升降机系列大轮播图3		
	
	$get_mcxl_simg1=get_banner(60);
	$mcxl_simg1 = $get_mcxl_simg1[0];
	$smarty->assign('mcxl_simg1',   $mcxl_simg1);           // 获取单品特卖三楼门、窗系列小轮播图1
	$get_mcxl_simg2=get_banner(61);
	$mcxl_simg2 = $get_mcxl_simg2[0];
	$smarty->assign('mcxl_simg2',   $mcxl_simg2);           // 获取单品特卖三楼门、窗系列小轮播图2
	$get_mcxl_simg3=get_banner(62);
	$mcxl_simg3 = $get_mcxl_simg3[0];
	$smarty->assign('mcxl_simg3',   $mcxl_simg3);           // 获取单品特卖三楼门、窗系列小轮播图3	
	$get_mcxl_bimg1=get_banner(63);
	$mcxl_bimg1 = $get_mcxl_bimg1[0];
	$smarty->assign('mcxl_bimg1',   $mcxl_bimg1);           // 获取单品特卖三楼门、窗系列大轮播图1
	$get_mcxl_bimg2=get_banner(64);
	$mcxl_bimg2 = $get_mcxl_bimg2[0];
	$smarty->assign('mcxl_bimg2',   $mcxl_bimg2);           // 获取单品特卖三楼门、窗系列大轮播图2	
	$get_mcxl_bimg3=get_banner(65);
	$mcxl_bimg3 = $get_mcxl_bimg3[0];
	$smarty->assign('mcxl_bimg3',   $mcxl_bimg3);           // 获取单品特卖三楼门、窗系列大轮播图3	

	$get_zyxl_simg1=get_banner(66);
	$zyxl_simg1 = $get_zyxl_simg1[0];
	$smarty->assign('zyxl_simg1',   $zyxl_simg1);           // 获取单品特卖四楼桌、椅系列小轮播图1
	$get_zyxl_simg2=get_banner(67);
	$zyxl_simg2 = $get_zyxl_simg2[0];
	$smarty->assign('zyxl_simg2',   $zyxl_simg2);           // 获取单品特卖四楼桌、椅系列小轮播图2
	$get_zyxl_simg3=get_banner(68);
	$zyxl_simg3 = $get_zyxl_simg3[0];
	$smarty->assign('zyxl_simg3',   $zyxl_simg3);           // 获取单品特卖四楼桌、椅系列小轮播图3	
	$get_zyxl_bimg1=get_banner(69);
	$zyxl_bimg1 = $get_zyxl_bimg1[0];
	$smarty->assign('zyxl_bimg1',   $zyxl_bimg1);           // 获取单品特卖四楼桌、椅系列大轮播图1
	$get_zyxl_bimg2=get_banner(70);
	$zyxl_bimg2 = $get_zyxl_bimg2[0];
	$smarty->assign('zyxl_bimg2',   $zyxl_bimg2);           // 获取单品特卖四楼桌、椅系列大轮播图2	
	$get_zyxl_bimg3=get_banner(71);
	$zyxl_bimg3 = $get_zyxl_bimg3[0];
	$smarty->assign('zyxl_bimg3',   $zyxl_bimg3);           // 获取单品特卖四楼桌、椅系列大轮播图3	
	
	$get_dxl_simg1=get_banner(72);
	$dxl_simg1 = $get_dxl_simg1[0];
	$smarty->assign('dxl_simg1',   $dxl_simg1);           // 获取单品特卖五楼灯系列小轮播图1
	$get_dxl_simg2=get_banner(73);
	$dxl_simg2 = $get_dxl_simg2[0];
	$smarty->assign('dxl_simg2',   $dxl_simg2);           // 获取单品特卖五楼灯系列小轮播图2
	$get_dxl_simg3=get_banner(74);
	$dxl_simg3 = $get_dxl_simg3[0];
	$smarty->assign('dxl_simg3',   $dxl_simg3);           // 获取单品特卖五楼灯系列小轮播图3	
	$get_dxl_bimg1=get_banner(75);
	$dxl_bimg1 = $get_dxl_bimg1[0];
	$smarty->assign('dxl_bimg1',   $dxl_bimg1);           // 获取单品特卖五楼灯系列大轮播图1
	$get_dxl_bimg2=get_banner(76);
	$dxl_bimg2 = $get_dxl_bimg2[0];
	$smarty->assign('dxl_bimg2',   $dxl_bimg2);           // 获取单品特卖五楼灯系列大轮播图2	
	$get_dxl_bimg3=get_banner(77);
	$dxl_bimg3 = $get_dxl_bimg3[0];
	$smarty->assign('dxl_bimg3',   $dxl_bimg3);           // 获取单品特卖五楼灯系列大轮播图3

	$get_pjxl_simg1=get_banner(78);
	$pjxl_simg1 = $get_pjxl_simg1[0];
	$smarty->assign('pjxl_simg1',   $pjxl_simg1);           // 获取单品特卖六楼配件系列小轮播图1
	$get_pjxl_simg2=get_banner(79);
	$pjxl_simg2 = $get_pjxl_simg2[0];
	$smarty->assign('pjxl_simg2',   $pjxl_simg2);           // 获取单品特卖六楼配件系列小轮播图2
	$get_pjxl_simg3=get_banner(80);
	$pjxl_simg3 = $get_pjxl_simg3[0];
	$smarty->assign('pjxl_simg3',   $pjxl_simg3);           // 获取单品特卖六楼配件系列小轮播图3	
	$get_pjxl_bimg1=get_banner(81);
	$pjxl_bimg1 = $get_pjxl_bimg1[0];
	$smarty->assign('pjxl_bimg1',   $pjxl_bimg1);           // 获取单品特卖六楼配件系列大轮播图1
	$get_pjxl_bimg2=get_banner(82);
	$pjxl_bimg2 = $get_pjxl_bimg2[0];
	$smarty->assign('pjxl_bimg2',   $pjxl_bimg2);           // 获取单品特卖六楼配件系列大轮播图2	
	$get_pjxl_bimg3=get_banner(83);
	$pjxl_bimg3 = $get_pjxl_bimg3[0];
	$smarty->assign('pjxl_bimg3',   $pjxl_bimg3);           // 获取单品特卖六楼配件系列大轮播图3	

	$get_spxl_simg1=get_banner(84);
	$spxl_simg1 = $get_spxl_simg1[0];
	$smarty->assign('spxl_simg1',   $spxl_simg1);           // 获取单品特卖七楼饰品系列小轮播图1
	$get_spxl_simg2=get_banner(85);
	$spxl_simg2 = $get_spxl_simg2[0];
	$smarty->assign('spxl_simg2',   $spxl_simg2);           // 获取单品特卖七楼饰品系列小轮播图2
	$get_spxl_simg3=get_banner(86);
	$spxl_simg3 = $get_spxl_simg3[0];
	$smarty->assign('spxl_simg3',   $spxl_simg3);           // 获取单品特卖七楼饰品系列小轮播图3	
	$get_spxl_bimg1=get_banner(87);
	$spxl_bimg1 = $get_spxl_bimg1[0];
	$smarty->assign('spxl_bimg1',   $spxl_bimg1);           // 获取单品特卖七楼饰品系列大轮播图1
	$get_spxl_bimg2=get_banner(88);
	$spxl_bimg2 = $get_spxl_bimg2[0];
	$smarty->assign('spxl_bimg2',   $spxl_bimg2);           // 获取单品特卖七楼饰品系列大轮播图2	
	$get_spxl_bimg3=get_banner(89);
	$spxl_bimg3 = $get_spxl_bimg3[0];
	$smarty->assign('spxl_bimg3',   $spxl_bimg3);           // 获取单品特卖七楼饰品系列大轮播图3	

	$get_mjspx_left1=get_banner(84);
	$mjspx_left1 = $get_mjspx_left1[0];
	$smarty->assign('mjspx_left1',   $mjspx_left1);           // 获取单品特卖美家实拍秀左一	
	$get_mjspx_left2=get_banner(84);
	$mjspx_left2 = $get_mjspx_left2[0];
	$smarty->assign('mjspx_left2',   $mjspx_left2);           // 获取单品特卖美家实拍秀左二	
	$get_mjspx_right1=get_banner(84);
	$mjspx_right1 = $get_mjspx_right1[0];
	$smarty->assign('mjspx_right1',   $mjspx_right1);           // 获取单品特卖美家实拍秀右一	
	$get_mjspx_right2=get_banner(84);
	$mjspx_right2 = $get_mjspx_right2[0];
	$smarty->assign('mjspx_right2',   $mjspx_right2);           // 获取单品特卖美家实拍秀右一	
	$get_mjspx_mid=get_banner(84);
	$mjspx_mid = $get_mjspx_mid[0];
	$smarty->assign('mjspx_mid',   $mjspx_mid);           // 获取单品特卖美家实拍秀中间	
    /* 首页主广告设置 */
    $smarty->assign('index_ad',     $_CFG['index_ad']);
    if ($_CFG['index_ad'] == 'cus')
    {
        $sql = 'SELECT ad_type, content, url FROM ' . $ecs->table("ad_custom") . ' WHERE ad_status = 1';
        $ad = $db->getRow($sql, true);
        $smarty->assign('ad', $ad);
    }

    /* links */
    $links = index_get_links();
    $smarty->assign('img_links',       $links['img']);
    $smarty->assign('txt_links',       $links['txt']);
    $smarty->assign('data_dir',        DATA_DIR);       // 数据目录

    /* 首页推荐分类 */
    $cat_recommend_res = $db->getAll("SELECT c.cat_id, c.cat_name, cr.recommend_type FROM " . $ecs->table("cat_recommend") . " AS cr INNER JOIN " . $ecs->table("category") . " AS c ON cr.cat_id=c.cat_id");
    if (!empty($cat_recommend_res))
    {
        $cat_rec_array = array();
        foreach($cat_recommend_res as $cat_recommend_data)
        {
            $cat_rec[$cat_recommend_data['recommend_type']][] = array('cat_id' => $cat_recommend_data['cat_id'], 'cat_name' => $cat_recommend_data['cat_name']);
        }
        $smarty->assign('cat_rec', $cat_rec);
    }

    /* 页面中的动态内容 */
    assign_dynamic('index');
}

$smarty->display('danpin.dwt', $cache_id);

/*------------------------------------------------------ */
//-- PRIVATE FUNCTIONS
/*------------------------------------------------------ */

/**
 * 调用发货单查询
 *
 * @access  private
 * @return  array
 */
function index_get_invoice_query()
{
    $sql = 'SELECT o.order_sn, o.invoice_no, s.shipping_code FROM ' . $GLOBALS['ecs']->table('order_info') . ' AS o' .
            ' LEFT JOIN ' . $GLOBALS['ecs']->table('shipping') . ' AS s ON s.shipping_id = o.shipping_id' .
            " WHERE invoice_no > '' AND shipping_status = " . SS_SHIPPED .
            ' ORDER BY shipping_time DESC LIMIT 10';
    $all = $GLOBALS['db']->getAll($sql);

    foreach ($all AS $key => $row)
    {
        $plugin = ROOT_PATH . 'includes/modules/shipping/' . $row['shipping_code'] . '.php';

        if (file_exists($plugin))
        {
            include_once($plugin);

            $shipping = new $row['shipping_code'];
            $all[$key]['invoice_no'] = $shipping->query((string)$row['invoice_no']);
        }
    }

    clearstatcache();

    return $all;
}

/**
 * 获得最新的文章列表。
 *
 * @access  private
 * @return  array
 */
function index_get_new_articles()
{
    $sql = 'SELECT a.article_id, a.title, ac.cat_name, a.add_time, a.file_url, a.open_type, ac.cat_id, ac.cat_name ' .
            ' FROM ' . $GLOBALS['ecs']->table('article') . ' AS a, ' .
                $GLOBALS['ecs']->table('article_cat') . ' AS ac' .
            ' WHERE a.is_open = 1 AND a.cat_id = ac.cat_id AND ac.cat_type = 1' .
            ' ORDER BY a.article_type DESC, a.add_time DESC LIMIT ' . $GLOBALS['_CFG']['article_number'];
    $res = $GLOBALS['db']->getAll($sql);

    $arr = array();
    foreach ($res AS $idx => $row)
    {
        $arr[$idx]['id']          = $row['article_id'];
        $arr[$idx]['title']       = $row['title'];
        $arr[$idx]['short_title'] = $GLOBALS['_CFG']['article_title_length'] > 0 ?
                                        sub_str($row['title'], $GLOBALS['_CFG']['article_title_length']) : $row['title'];
        $arr[$idx]['cat_name']    = $row['cat_name'];
        $arr[$idx]['add_time']    = local_date($GLOBALS['_CFG']['date_format'], $row['add_time']);
        $arr[$idx]['url']         = $row['open_type'] != 1 ?
                                        build_uri('article', array('aid' => $row['article_id']), $row['title']) : trim($row['file_url']);
        $arr[$idx]['cat_url']     = build_uri('article_cat', array('acid' => $row['cat_id']), $row['cat_name']);
    }

    return $arr;
}

/**
 * 获得最新的团购活动
 *
 * @access  private
 * @return  array
 */
function index_get_group_buy()
{
    $time = gmtime();
    $limit = get_library_number('group_buy', 'index');

    $group_buy_list = array();
    if ($limit > 0)
    {
        $sql = 'SELECT gb.act_id AS group_buy_id, gb.goods_id, gb.ext_info, gb.goods_name, g.goods_thumb, g.goods_img ' .
                'FROM ' . $GLOBALS['ecs']->table('goods_activity') . ' AS gb, ' .
                    $GLOBALS['ecs']->table('goods') . ' AS g ' .
                "WHERE gb.act_type = '" . GAT_GROUP_BUY . "' " .
                "AND g.goods_id = gb.goods_id " .
                "AND gb.start_time <= '" . $time . "' " .
                "AND gb.end_time >= '" . $time . "' " .
                "AND g.is_delete = 0 " .
                "ORDER BY gb.act_id DESC " .
                "LIMIT $limit" ;
        $res = $GLOBALS['db']->query($sql);

        while ($row = $GLOBALS['db']->fetchRow($res))
        {
            /* 如果缩略图为空，使用默认图片 */
            $row['goods_img'] = get_image_path($row['goods_id'], $row['goods_img']);
            $row['thumb'] = get_image_path($row['goods_id'], $row['goods_thumb'], true);

            /* 根据价格阶梯，计算最低价 */
            $ext_info = unserialize($row['ext_info']);
            $price_ladder = $ext_info['price_ladder'];
            if (!is_array($price_ladder) || empty($price_ladder))
            {
                $row['last_price'] = price_format(0);
            }
            else
            {
                foreach ($price_ladder AS $amount_price)
                {
                    $price_ladder[$amount_price['amount']] = $amount_price['price'];
                }
            }
            ksort($price_ladder);
            $row['last_price'] = price_format(end($price_ladder));
            $row['url'] = build_uri('group_buy', array('gbid' => $row['group_buy_id']));
            $row['short_name']   = $GLOBALS['_CFG']['goods_name_length'] > 0 ?
                                           sub_str($row['goods_name'], $GLOBALS['_CFG']['goods_name_length']) : $row['goods_name'];
            $row['short_style_name']   = add_style($row['short_name'],'');
            $group_buy_list[] = $row;
        }
    }

    return $group_buy_list;
}

/**
 * 取得拍卖活动列表
 * @return  array
 */
function index_get_auction()
{
    $now = gmtime();
    $limit = get_library_number('auction', 'index');
    $sql = "SELECT a.act_id, a.goods_id, a.goods_name, a.ext_info, g.goods_thumb ".
            "FROM " . $GLOBALS['ecs']->table('goods_activity') . " AS a," .
                      $GLOBALS['ecs']->table('goods') . " AS g" .
            " WHERE a.goods_id = g.goods_id" .
            " AND a.act_type = '" . GAT_AUCTION . "'" .
            " AND a.is_finished = 0" .
            " AND a.start_time <= '$now'" .
            " AND a.end_time >= '$now'" .
            " AND g.is_delete = 0" .
            " ORDER BY a.start_time DESC" .
            " LIMIT $limit";
    $res = $GLOBALS['db']->query($sql);

    $list = array();
    while ($row = $GLOBALS['db']->fetchRow($res))
    {
        $ext_info = unserialize($row['ext_info']);
        $arr = array_merge($row, $ext_info);
        $arr['formated_start_price'] = price_format($arr['start_price']);
        $arr['formated_end_price'] = price_format($arr['end_price']);
        $arr['thumb'] = get_image_path($row['goods_id'], $row['goods_thumb'], true);
        $arr['url'] = build_uri('auction', array('auid' => $arr['act_id']));
        $arr['short_name']   = $GLOBALS['_CFG']['goods_name_length'] > 0 ?
                                           sub_str($arr['goods_name'], $GLOBALS['_CFG']['goods_name_length']) : $arr['goods_name'];
        $arr['short_style_name']   = add_style($arr['short_name'],'');
        $list[] = $arr;
    }

    return $list;
}

/**
 * 获得所有的友情链接
 *
 * @access  private
 * @return  array
 */
function index_get_links()
{
    $sql = 'SELECT link_logo, link_name, link_url FROM ' . $GLOBALS['ecs']->table('friend_link') . ' ORDER BY show_order';
    $res = $GLOBALS['db']->getAll($sql);

    $links['img'] = $links['txt'] = array();

    foreach ($res AS $row)
    {
        if (!empty($row['link_logo']))
        {
            $links['img'][] = array('name' => $row['link_name'],
                                    'url'  => $row['link_url'],
                                    'logo' => $row['link_logo']);
        }
        else
        {
            $links['txt'][] = array('name' => $row['link_name'],
                                    'url'  => $row['link_url']);
        }
    }

    return $links;
}

function get_comments($num)
{
        
           $sql = 'SELECT a.*,b.* FROM '. $GLOBALS['ecs']->table('comment') .

            ' AS a,'. $GLOBALS['ecs']->table('goods') .'AS b WHERE a.status = 1 AND a.parent_id = 0 and a.comment_type=0 and a.id_value=b.goods_id '.

            ' ORDER BY a.add_time DESC';



  if ($num > 0)
  {
   $sql .= ' LIMIT ' . $num;
  }
  //echo $sql;
        
  $res = $GLOBALS['db']->getAll($sql);
  $comments = array();
  foreach ($res AS $idx => $row)
  {

   $comments[$idx]['user_name']       = $row['user_name'];
   $comments[$idx]['content']       = $row['content'];
   $comments[$idx]['id_value']       = $row['id_value'];
   $comments[$idx]['add_time']      = date("Y-m-d", $row['add_time']);
   $comments[$idx]['goods_name']       = $row['goods_name'];
   $comments[$idx]['goods_thumb']       = $row['goods_thumb'];
   $comments[$idx]['comment_rank']       = $row['comment_rank'];
  }
  return $comments;
}

?>