<?php

define('IN_ECS', true);

require(dirname(__FILE__) . '/includes/init.php');



$sql = "select * from ecs_city where pid = 0";


$provinces = $GLOBALS['db']->getAll($sql);


$sql = "select * from ecs_city where  pid <> 0";


$city = $GLOBALS['db']->getAll($sql);


$sql = "SELECT * FROM ecs_loupan";


$loupan = $GLOBALS['db']->getAll($sql);




$sql = "SELECT * FROM ecs_designer";


$designer = $GLOBALS['db']->getAll($sql);



$id=$_GET['id'];

$smarty->assign("home_style",$home_style);

$smarty->assign("id",$id);

$smarty->assign("designer",$designer);

$smarty->assign("loupan",$loupan);

$smarty->assign('city', $city);

$smarty->assign('provinces', $provinces);



$smarty->display("custom.htm");

