<?php
define('IN_ECS', true);
require(dirname(__FILE__) . '/includes/init.php');
	$id = intval($_GET['ask_id']);
	$type = $_GET['is_hot'];
	if($type == "set_hot")
	{
		$sql = "UPDATE ecs_daogou_ask set is_hot=1 WHERE ask_id=$id";
		$update = $db->query($sql);
		if($update)
		{
			echo "<script>alert('设置成功!');window.location.href='daogou_list.php'</script>";
		}
	} else if($type == "remove_hot"){
		$sql = "UPDATE ecs_daogou_ask set is_hot=0 WHERE ask_id=$id";
		$update = $db->query($sql);
		if($update)
		{
			echo "<script>alert('设置成功!');window.location.href='daogou_list.php'</script>";
		}
	}else if($type == "remove"){
		$sql = "DELETE ecs_daogou_ask,ecs_daogou_answer from ecs_daogou_ask LEFT JOIN ecs_daogou_answer ON ecs_daogou_ask.ask_id=ecs_daogou_answer.ask_id WHERE ecs_daogou_ask.ask_id=$id";
		$delete = $db->query($sql);
		if($delete)
		{
			echo "<script>alert('删除成功!');window.location.href='daogou_list.php'</script>";
		}
	}

$url = "daogou_list.php";
$param = array();
$sql = "SELECT count(*) as num FROM ecs_daogou_ask" ;
$query = $db->query($sql);
$row = mysql_fetch_assoc($query);
$count= $row['num'];

$page = intval($_GET['page']);//传入的页码

$offset = 20;

if($page>1){
    $limit = ($page-1)*$offset;
}else{
    $limit = 0;
}

$pages = get_pager($url, $param, $count, $page,$offset);
$prev = "<a href='".$pages['page_prev']."'>上一页</a>";
$next ="<a href='".$pages['page_next']."'>下一页</a>";


$sql = "SELECT * FROM ecs_daogou_ask order by is_hot =1 desc , ctime  desc LIMIT $limit,$offset";
$custom = $GLOBALS['db']->getAll($sql);
$city = array(
    1=>"北京",
    2=>"上海",
    3=>"广州",
);
$sql = "SELECT * FROM ecs_crowd";
$crowd = $GLOBALS['db']->getAll($sql);
$arr = array();
foreach($crowd as $k=>$v)
{
    $arr[$v['id']] = $v['name'];
}

$sql ="SELECT * FROM ecs_tag";
$tags = $GLOBALS['db']->getAll($sql);
$tag = array();
foreach($tags as $k=>$v)
{
    $tag[$v['tag_id']] = $v['tag_words'];
}
$smarty->assign("city",$city);
$smarty->assign("count",$count);
$smarty->assign("prev",$prev);
$smarty->assign("next",$next);
$smarty->assign("tag",$tag);
$smarty->assign('crowd',$arr);
$smarty->assign("custom",$custom);
$smarty->display("ask.htm");



function get_pager($url, $param, $record_count, $page = 1, $size = 10)
{
    $size = intval($size);

    if ($size < 1)
    {
        $size = 10;
    }

    $page = intval($page);
    if ($page < 1)
    {
        $page = 1;
    }

    $record_count = intval($record_count);

    $page_count = $record_count > 0 ? intval(ceil($record_count / $size)) : 1;
    if ($page > $page_count)
    {
        $page = $page_count;
    }
    /* 分页样式 */
    $pager['styleid'] = isset($GLOBALS['_CFG']['page_style'])? intval($GLOBALS['_CFG']['page_style']) : 0;

    $page_prev  = ($page > 1) ? $page - 1 : 2;

    $page_next  = ($page < $page_count) ? $page + 1 : $page_count;

    /* 将参数合成url字串 */
    $param_url = '?';
    foreach ($param AS $key => $value)
    {
        $param_url .= $key . '=' . $value . '&';
    }

    $pager['url']          = $url;
    $pager['start']        = ($page -1) * $size;
    $pager['page']         = $page;
    $pager['size']         = $size;
    $pager['record_count'] = $record_count;
    $pager['page_count']   = $page_count;

    if ($pager['styleid'] == 0)
    {
        $pager['page_first']   = $url . $param_url . 'page=1';

        $pager['page_prev']    = $url . $param_url . 'page=' . $page_prev;
        $pager['page_next']    = $url . $param_url . 'page=' . $page_next;
        $pager['page_last']    = $url . $param_url . 'page=' . $page_count;
        $pager['array']  = array();
        for ($i = 1; $i <= $page_count; $i++)
        {
            $pager['array'][$i] = $i;
        }
    }
    else
    {
        $_pagenum = 10;     // 显示的页码
        $_offset = 2;       // 当前页偏移值
        $_from = $_to = 0;  // 开始页, 结束页
        if($_pagenum > $page_count)
        {
            $_from = 1;
            $_to = $page_count;
        }
        else
        {
            $_from = $page - $_offset;
            $_to = $_from + $_pagenum - 1;
            if($_from < 1)
            {
                $_to = $page + 1 - $_from;
                $_from = 1;
                if($_to - $_from < $_pagenum)
                {
                    $_to = $_pagenum;
                }
            }
            elseif($_to > $page_count)
            {
                $_from = $page_count - $_pagenum + 1;
                $_to = $page_count;
            }
        }
        $url_format = $url . $param_url . 'page=';
        $pager['page_first'] = ($page - $_offset > 1 && $_pagenum < $page_count) ? $url_format . 1 : '';

        $pager['page_prev']  = ($page > 1) ? $url_format . $page_prev : '';

        $pager['page_next']  = ($page < $page_count) ? $url_format . $page_next : '';

        $pager['page_last']  = ($_to < $page_count) ? $url_format . $page_count : '';

        $pager['page_kbd']  = ($_pagenum < $page_count) ? true : false;

        $pager['page_number'] = array();

        for ($i=$_from;$i<=$_to;++$i)
        {
            $pager['page_number'][$i] = $url_format . $i;
        }
    }
    $pager['search'] = $param;

    return $pager;

}
