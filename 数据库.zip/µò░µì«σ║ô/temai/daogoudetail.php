<?php
/**
 * Created by PhpStorm.
 * User: lin
 * Date: 15/9/4
 * Time: 下午5:55
 */


define('IN_ECS', true);

require(dirname(__FILE__) . '/includes/init.php');

if ((DEBUG_MODE & 2) != 2)
{
    $smarty->caching = true;
}
$sql = "select da.ask_id,da.title,da.userid,da.ctime, da.daogou_column_id,da.province,da.city,da.describe,da.answer_num,u.user_name from ".$ecs->table('daogou_ask')." da left join ".$ecs->table('users')." u on da.userid = u.user_id where da.ask_id = ".intval($_GET['askid']);

$ask = $db->getRow($sql);
$ask['ctime'] = date('Y-m-d H:i:s',$ask['ctime']);
$ask_id = $ask['ask_id'];
$sql = "select daogou_column_id from ecs_daogou_ask where ask_id = $ask_id";
$daogou_column_id = $db->getOne($sql);
$sql = "select column_name from ecs_daogou_column where column_id = $daogou_column_id ";
$column_name = $db->getOne($sql);

$userid = $_SESSION['user_id'];
/*
 *  'action' => string 'addanswer' (length=9)
  'askid' => string '6' (length=1)
  'content' => string '为问友提供尽可能准确、详细和有效的回答，被采纳后将获得5积分哦~
 *
 * */

if($_POST['action'] == 'addanswer'){

    $insert_sql = "insert into ".$ecs->table('daogou_answer')." (ask_id,answer,userid,ctime) values({$_POST['askid']},'{$_POST['content']}',{$userid},".time().")";
    mysql_query($insert_sql);
	var_dump($insert_sql);
    mysql_query("update ".$ecs->table('daogou_ask')." set answer_num = answer_num+1 where ask_id = ".$_POST['askid']);
    if(mysql_query($sql)){
		echo "<script type='text/javascript'>";
		echo "alert('回答成功')";
		echo "</script>";
    }else{
        echo "<script type='text/javascript'>";
        echo "alert('回答失败')";
        echo "</script>";
    }	
}
/*获取普通答案*/
$sql_answer = "select da.answer,da.ctime,da.userid,da.is_best,u.user_name from ".$ecs->table('daogou_answer')." da left join ".$ecs->table('users')." u on u.user_id = da.userid where da.is_best = 0 and da.ask_id = ".intval($_GET['askid'])." order by da.ctime desc";
$arr_answer = $db->getAll($sql_answer);
foreach($arr_answer as $key => $value){
    $arr_answer[$key]['ctime'] = date('Y-m-d H:i:s', $value['ctime']);
    $arr_answer[$key]['ansnum'] = $db->getOne("select count(*) from ".$ecs->table('daogou_answer')." where userid = ".$value['userid']);
    $arr_answer[$key]['excelent'] = $db->getOne("select count(*) from ".$ecs->table('daogou_answer')." where userid= ".$value['userid']." and is_excelent = 1");
}
/*获取最佳答案*/
$sql = "select da.answer,da.ctime,da.userid,da.is_best,u.user_name from ".$ecs->table('daogou_answer')." da left join ".$ecs->table('users')." u on u.user_id = da.userid where da.is_best = 1 and da.ask_id = ".intval($_GET['askid'])." order by da.ctime desc limit 1";
$arr_answer_best = $db->getAll($sql);

foreach($arr_answer_best as $key => $value){
    $arr_answer_best[$key]['ctime'] = date('Y-m-d H:i:s', $value['ctime']);
    $arr_answer_best[$key]['ansnum'] = $db->getOne("select count(*) from ".$ecs->table('daogou_answer')." where userid = ".$value['userid']);
    $arr_answer_best[$key]['excelent'] = $db->getOne("select count(*) from ".$ecs->table('daogou_answer')." where userid= ".$value['userid']." and is_excelent = 1");
}
$num = count($arr_answer)+count($arr_answer_best);
/*****/
/***其他wenti ***/
$sql_othask = "select * from ".$ecs->table('daogou_ask')." where daogou_column_id in (select daogou_column_id from ecs_daogou_ask where ask_id = ".intval($_GET['askid']).") and ask_id !=".intval($_GET['askid'])." limit 10";
$arr_othask = $db->getAll($sql_othask);
foreach($arr_othask as $key => $value){
    $sql_ansnum = "select count(*) as sum from ".$ecs->table('daogou_answer')." where ask_id = {$value['ask_id']}";
    $sum = $db->getOne($sql_ansnum);
    $arr_othask[$key]['num'] = $sum;
    $arr_othask[$key]['ctime'] = date('Y-m-d H:i:s',$value['ctime']);
}

/********/
if($_POST['act']){
    $ctime = time();
	$tel = $_POST['tel'];
	$name = $_POST['name'];
	if(empty($tel) || empty($name)){
        echo "<script type='text/javascript'>";
        echo "alert('称呼或手机号码不能为空')";
        echo "</script>";	
		
	}
		$sql = "insert into ".$ecs->table('lazy')." (`ctime`,`tel`,`name`) values ($ctime,'$tel','$name')";
		
		if(mysql_query($sql)){

			echo "<script type='text/javascript'>";
			echo "alert('提交成功')";
			echo "</script>";
		}else{
			echo "<script type='text/javascript'>";
			echo "alert('提交失败')";
			echo "</script>";
		}
	
}

$smarty->assign('youhui_articles', index_get_class_articles(13,5));   // 调取优惠活动文章
$smarty->assign('xinshou_articles', index_get_class_footer_articles(14,5));   // 调取新手上路文章
$smarty->assign('liangfang_articles', index_get_class_footer_articles(15,5));   // 调取量房设计文章
$smarty->assign('anquan_articles', index_get_class_footer_articles(16,5));   // 调取安全保障文章
$smarty->assign('duxiang_articles', index_get_class_footer_articles(17,5));   // 调取会员独享文章
$smarty->assign('chuangyi_articles', index_get_class_footer_articles(27,6));   // 调取创意家居文章
$smarty->assign('kuaixun_articles', index_get_class_footer_articles(28,6));   // 调取缘和快讯文章
$smarty->assign('wenti_articles', index_get_class_footer_articles(29,3));   // 调取常见问题文章
$smarty->assign('guanjianci_articles', index_get_class_footer_articles(30,3));   // 调取关键词文章
$smarty->assign('youqinglianjie', get_link_footer(1));   // 调取友情链接
$smarty->assign('hezuowangzhan', get_link_footer(2));   // 调取合作网站
$smarty->assign('rementuijian', get_link_footer(3));   // 调取热门推荐
$smarty->assign('get_hot_ask', get_hot_ask());   // 调取精华问题
$smarty->assign('othask',$arr_othask);
$smarty->assign('answer',$arr_answer);
$smarty->assign('answer_best',$arr_answer_best);
$smarty->assign('num',$num);
$smarty->assign('ask',$ask);
$smarty->assign('column_name',$column_name);
$smarty->assign('daogou_column_id',$daogou_column_id);
$smarty->assign('categories',      get_categories_tree()); // 分类树
$get_index_banner=get_banner(2);
$index_banner = $get_index_banner[0];
$smarty->assign('index_banner',   $index_banner);           // 获取网站顶部banner	

$get_daogou_index_right1=get_banner(95);
$daogou_index_right1 = $get_daogou_index_right1[0];
$smarty->assign('daogou_index_right1',   $daogou_index_right1);           // 获取个性定制轮播图1	
$get_daogou_index_right2=get_banner(96);
$daogou_index_right2 = $get_daogou_index_right2[0];
$smarty->assign('daogou_index_right2',   $daogou_index_right2);           // 获取个性定制轮播图2	
$get_daogou_index_right3=get_banner(97);
$daogou_index_right3 = $get_daogou_index_right3[0];
$smarty->assign('daogou_index_right3',   $daogou_index_right3);           // 获取个性定制轮播图3 
$smarty->display('daogoudetail.dwt');

//获取精华问题
function get_hot_ask()
{
$sql = "SELECT * FROM " .$GLOBALS['ecs']->table('daogou_ask'). " where is_hot = 1  ORDER BY ctime DESC LIMIT 5" ;
$res = $GLOBALS['db']->getAll($sql);
$arr = array();
foreach ($res AS $idx => $row)
{
$arr[$idx]['title'] = $row['title'];
$arr[$idx]['ask_id'] = $row['ask_id'];
$arr[$idx]['daogou_column_id'] = $row['daogou_column_id'];
$daogou_column_id = $arr[$idx]['daogou_column_id'];
$sql ="select column_name from ecs_daogou_column where column_id = $daogou_column_id ";
$res = $GLOBALS['db']->getAll($sql);
$arr[$idx]['column_name'] = $res[0]['column_name'];
}
return $arr;
} 
?>