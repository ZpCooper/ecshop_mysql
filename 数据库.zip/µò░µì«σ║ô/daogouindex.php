<?php
/**
 * Created by PhpStorm.
 * User: lin
 * Date: 15/8/30
 * Time: 上午12:23
 */

define('IN_ECS', true);

require(dirname(__FILE__) . '/includes/init.php');

if ((DEBUG_MODE & 2) != 2)
{
    $smarty->caching = true;
}

$top_column = $db->getAll("select column_id,column_name from ".$ecs->table('daogou_column')." where parent_id=0");
//var_dump($top_column);
$new_column = array();
foreach($top_column as $key => $value){
    $new_column[$value['column_id']] = $value['column_name'];
    //$top_column[$key][$value['column_id']] = $db->getAll("select column_id,column_name from ".$ecs->table('daogou_column')." where parent_id =".$value['column_id']);
}

//var_dump($new_column);
$column = '';
foreach($new_column as $key=> $value){
    $column .=  "<div class='ask_type_item current'><h3 class='item_hd'><a href='daogoulist.php' target='_blank'><i class='ask_ico_index ask_ico_index1'></i>{$value} <i class='arrow_green'></i></a></h3>";
    $sql = "select column_id,column_name from ".$ecs->table('daogou_column')." where parent_id = $key";
    $res = mysql_query($sql);
    $column .= "<div class='item_bd clearfix'>";
    while($row = mysql_fetch_assoc($res)){
        $column .= "<a href='daogoulist.php?columnid={$row['column_id']}' class='type_lnk'>{$row['column_name']}</a>";
    }
    $column .= "</div></div>";
}

$sql_newask = "select ask_id,title,ctime,answer_num from ".$ecs->table('daogou_ask')." order by ctime desc limit 10";
$arr_newask = $db->getAll($sql_newask);
foreach($arr_newask as $key => $value){
    $arr_newask[$key]['ctime'] = formattime($value['ctime']);
}

$sql_anser = "select count(*) from " .$ecs->table('daogou_answer');
$num_anser = $db->getOne($sql_anser);



if($_POST['act']){
    $ctime = time();
	$tel = $_POST['tel'];
	$name = $_POST['name'];
	if(empty($tel) || empty($name)){
        echo "<script type='text/javascript'>";
        echo "alert('称呼或手机号码不能为空')";
        echo "</script>";	
		
	}
		$sql = "insert into ".$ecs->table('lazy')." (`ctime`,`tel`,`name`) values ($ctime,'$tel','$name')";
		
		if(mysql_query($sql)){

			echo "<script type='text/javascript'>";
			echo "alert('提交成功')";
			echo "</script>";
		}else{
			echo "<script type='text/javascript'>";
			echo "alert('提交失败')";
			echo "</script>";
		}
	
}

function formattime($time){
    $current = time();
    $swap = $current - $time;
    $flag = $swap/60;
    if($flag<1){
        return $swap.'秒';
    }elseif($flag<=59){
        return ceil($flag).'分钟';
    }elseif($flag<=1440){
        return ceil($flag/60).'小时';
    }else{
        return ceil($flag/1440).'天';
    }
}
$smarty->assign('youhui_articles', index_get_class_articles(13,5));   // 调取优惠活动文章
$smarty->assign('xinshou_articles', index_get_class_footer_articles(14,5));   // 调取新手上路文章
$smarty->assign('liangfang_articles', index_get_class_footer_articles(15,5));   // 调取量房设计文章
$smarty->assign('anquan_articles', index_get_class_footer_articles(16,5));   // 调取安全保障文章
$smarty->assign('duxiang_articles', index_get_class_footer_articles(17,5));   // 调取会员独享文章
$smarty->assign('chuangyi_articles', index_get_class_footer_articles(27,6));   // 调取创意家居文章
$smarty->assign('kuaixun_articles', index_get_class_footer_articles(28,6));   // 调取缘和快讯文章
$smarty->assign('wenti_articles', index_get_class_footer_articles(29,3));   // 调取常见问题文章
$smarty->assign('guanjianci_articles', index_get_class_footer_articles(30,3));   // 调取关键词文章
$smarty->assign('youqinglianjie', get_link_footer(1));   // 调取友情链接
$smarty->assign('hezuowangzhan', get_link_footer(2));   // 调取合作网站
$smarty->assign('rementuijian', get_link_footer(3));   // 调取热门推荐
$smarty->assign('get_hot_ask', get_hot_ask());   // 调取精华问题
$smarty->assign('anser',$num_anser);
$smarty->assign('newask',$arr_newask);
$smarty->assign('get_newanswer',get_newanswer());
$smarty->assign('categories',      get_categories_tree()); // 分类树
$smarty->assign('column' ,$column);
$get_index_banner=get_banner(2);
$index_banner = $get_index_banner[0];
$smarty->assign('index_banner',   $index_banner);           // 获取网站顶部banner	

$get_best_img=get_banner(94);
$best_img = $get_best_img[0];
$smarty->assign('best_img',   $best_img);           // 获取精华问答banner图 

$get_daogou_index_right1=get_banner(95);
$daogou_index_right1 = $get_daogou_index_right1[0];
$smarty->assign('daogou_index_right1',   $daogou_index_right1);           // 获取个性定制轮播图1	
$get_daogou_index_right2=get_banner(96);
$daogou_index_right2 = $get_daogou_index_right2[0];
$smarty->assign('daogou_index_right2',   $daogou_index_right2);           // 获取个性定制轮播图2	
$get_daogou_index_right3=get_banner(97);
$daogou_index_right3 = $get_daogou_index_right3[0];
$smarty->assign('daogou_index_right3',   $daogou_index_right3);           // 获取个性定制轮播图3 
$smarty->display('daogouindex.dwt');
//获取精华问题
function get_hot_ask()
{
$sql = "SELECT * FROM " .$GLOBALS['ecs']->table('daogou_ask'). " where is_hot = 1  ORDER BY ctime DESC LIMIT 7" ;
$res = $GLOBALS['db']->getAll($sql);
$arr = array();
foreach ($res AS $idx => $row)
{
$arr[$idx]['title'] = $row['title'];
$arr[$idx]['ask_id'] = $row['ask_id'];
$arr[$idx]['daogou_column_id'] = $row['daogou_column_id'];
$daogou_column_id = $arr[$idx]['daogou_column_id'];
$sql ="select column_name from ecs_daogou_column where column_id = $daogou_column_id ";
$res = $GLOBALS['db']->getAll($sql);
$arr[$idx]['column_name'] = $res[0]['column_name'];
}
return $arr;
} 
//获取最新回答
function get_newanswer()
{

$sql = "SELECT * FROM " .$GLOBALS['ecs']->table('daogou_answer'). " ORDER BY ctime DESC LIMIT 10" ;
$res = $GLOBALS['db']->getAll($sql);
$arr = array();
foreach ($res AS $idx => $row)
{
$arr[$idx]['ask_id'] = $row['ask_id'];
$arr[$idx]['answer'] = $row['answer'];
$arr[$idx]['ctime'] = formattime($row['ctime']);
$ask_id = $arr[$idx]['ask_id'];
$sql ="select * from ecs_daogou_ask where ask_id = $ask_id order by ctime desc limit 1";
$res = $GLOBALS['db']->getAll($sql);
$arr[$idx]['title'] = $res[0]['title'];
$arr[$idx]['userid'] = $row['userid'];
$userid = $arr[$idx]['userid'];
$sql = "select user_name from ecs_users where user_id = $userid";
$res = $GLOBALS['db']->getRow($sql);
$arr[$idx]['user_name'] = $res['user_name'];
}
return $arr;
} 
?>