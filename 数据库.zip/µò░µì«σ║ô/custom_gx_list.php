<?php

/**

 * 个性定制

 * ============================================================================
*/

define('IN_ECS', true);

require(dirname(__FILE__) . '/includes/init.php');

$sql='select * from ecs_custom_cat';

$custom_cat= $GLOBALS['db']->getAll($sql);

assign_template();

$id = intval($_GET['id']);

if($id ==0){

	$id =4;

}

//风格
$styles_screen = $db->getAll("select * from ".$ecs->table('custom_style'));
$smarty->assign('styles_screen',$styles_screen);

//价格

$prices_screen = $db->getAll("select price from ".$ecs->table('custom_gx') . "WHERE price!=0 AND cat_id=$id GROUP BY price ORDER BY price");
$smarty->assign('prices_screen',$prices_screen);

$style_screen_id = isset($_GET['style_screen_id']) ? intval($_GET['style_screen_id']) : '';
$price_screen_id = isset($_GET['price_screen_id']) ? trim($_GET['price_screen_id']) : '';

$smarty->assign('style_screen_id',$style_screen_id);
$smarty->assign('price_screen_id',$price_screen_id);

$where = '';
$param = array();
if(!empty($id)){
    $where .= "`cat_id` = $id AND ";
    $param['cat_id'] = $id;
}
if(!empty($style_screen_id)){
    $where .= "`style_id` = $style_screen_id AND ";
    $param['style_screen_id'] = $style_screen_id;
}
if(!empty($price_screen_id)){
    $where .= "`price` = $price_screen_id AND ";
    $param['price_screen_id'] = $price_screen_id;
}

$where .= 1;


//①获得第几页

$page = isset($_REQUEST['page']) && intval($_REQUEST['page']) > 0 ? intval($_REQUEST['page'])  : 1;

//②分页大小

$size = 12;

if($page>1){

    $limit = ($page-1)*$size;

}else{

    $limit = 0;

}

//③总的记录数，你可以用sql查询出来

$sql = "SELECT COUNT(*) FROM  ecs_custom_gx where $where";

$record_count = $GLOBALS['db']->getOne($sql);

//④生成分页
$pager = get_pager('custom_gx_list.php', $param, $record_count, $page,$size);

//⑤赋值到模板

$smarty->assign('pager', $pager);



$sql="select * from ecs_custom_gx where $where limit $limit,$size";

$custom_gx_list = $GLOBALS['db']->getAll($sql);

$position = assign_ur_here();

$smarty->assign('page_title',      $position['title']);    // 页面标题

$smarty->assign('ur_here',         $position['ur_here']);  // 当前位置

/* meta information */

$smarty->assign('keywords',        htmlspecialchars($_CFG['shop_keywords']));

$smarty->assign('description',     htmlspecialchars($_CFG['shop_desc']));

$smarty->assign('flash_theme',     $_CFG['flash_theme']);  // Flash轮播图片模板

$smarty->assign('categories',      get_categories_tree()); // 分类树

$smarty->assign('custom_cat',      $custom_cat);

$smarty->assign('custom_gx_list',      $custom_gx_list);// 分类筛选- 个性定制

$smarty->assign('id',      $id);

/**
 * ajax获取风格列表
 */
 if ($_REQUEST['act'] == 'get_style_list') {
     $style_id = $_REQUEST['style_id']; // style_id 自己定义的
     $sql = "select * from ecs_custom_style where style_id = $style_id ";
     $styles = $GLOBALS['db']->getAll($sql);
     $ret = array();
     if ($styles) {
         $ret['is_ok'] = true;
         $ret['style_list'] = $styles;
     } else  {
         $ret['is_ok'] = false;
         $ret['style_list'] = '';
     }
     echo json_encode($ret);exit;
 }

 /**
 * ajax获取价格列表
 */
 if ($_REQUEST['act'] == 'get_price_list') {
     $price_id = $_REQUEST['price_id'];
     $sql = "select * from ecs_custom_gx where price = $price_id ";
     $prices = $GLOBALS['db']->getAll($sql);
     $ret = array();
	 
	 
     if ($prices) {
         $ret['is_ok'] = true;
         $ret['price_list'] = $prices;
     } else  {
         $ret['is_ok'] = false;
         $ret['price_list'] = '';
     }
	 
     echo json_encode($ret);
	 exit;
 }


$smarty->assign('get_wofangchangjianwenti',      index_get_class_footer_articles(31,8));//获取卧房常见问题解答

$smarty->assign('get_shufangchangjianwenti',      index_get_class_footer_articles(32,8));//获取书房常见问题解答

$smarty->assign('get_qingshaonianfangchangjianwenti',      index_get_class_footer_articles(33,8));//获取青少年房常见问题解答

$smarty->assign('get_kecantingchangjianwenti',      index_get_class_footer_articles(34,8));//获取客餐厅常见问题解答

$smarty->assign('get_yangtaichangjianwenti',      index_get_class_footer_articles(35,8));//获取阳台常见问题解答

$smarty->assign('get_wofangdingzhi',      index_get_class_footer_articles(21,4));//获取卧房定制攻略

$smarty->assign('get_shufangdingzhi',      index_get_class_footer_articles(22,4));//获取书房定制攻略

$smarty->assign('get_qingshaonianfangdingzhi',      index_get_class_footer_articles(23,4));//获取青少年房定制攻略

$smarty->assign('get_kecantingdingzhi',      index_get_class_footer_articles(25,4));//获取客餐厅定制攻略

$smarty->assign('get_yangtaidingzhi',      index_get_class_footer_articles(24,4));//获取阳台定制攻略

$smarty->assign('get_tongyiwofang',      index_get_class_footer_articles(37,4));//获取同一卧房，无限可能

$smarty->assign('get_tongyishufang',      index_get_class_footer_articles(38,4));//获取同一书房，无限可能

$smarty->assign('get_tongyiqingshaonianfang',      index_get_class_footer_articles(39,4));//获取同一青少年房，无限可能

$smarty->assign('get_tongyikecanting',      index_get_class_footer_articles(40,4));//获取同一客餐厅，无限可能

$smarty->assign('get_tongyiyangtai',      index_get_class_footer_articles(41,4));//获取同一阳台，无限可能

$smarty->assign('get_wofangjingdian',      get_jingdiandingzhi(4));//获取卧房经典定制

$smarty->assign('get_shufangjingdian',      get_jingdiandingzhi(5));//获取书房经典定制

$smarty->assign('get_qingshaonianfangjingdian',      get_jingdiandingzhi(6));//获取青少年房经典定制

$smarty->assign('get_kecantingjingdian',      get_jingdiandingzhi(20));//获取客餐厅经典定制

$smarty->assign('get_yangtaijingdian',      get_jingdiandingzhi(19));//获取阳台经典定制

$smarty->assign('youhui_articles', index_get_class_articles(13,5));   // 调取优惠活动文章

$smarty->assign('xinshou_articles', index_get_class_footer_articles(14,5));   // 调取新手上路文章

$smarty->assign('liangfang_articles', index_get_class_footer_articles(15,5));   // 调取量房设计文章

$smarty->assign('anquan_articles', index_get_class_footer_articles(16,5));   // 调取安全保障文章

$smarty->assign('duxiang_articles', index_get_class_footer_articles(17,5));   // 调取会员独享文章

$smarty->assign('chuangyi_articles', index_get_class_footer_articles(27,6));   // 调取创意家居文章

$smarty->assign('kuaixun_articles', index_get_class_footer_articles(28,6));   // 调取缘和快讯文章

$smarty->assign('wenti_articles', index_get_class_footer_articles(29,3));   // 调取常见问题文章

$smarty->assign('guanjianci_articles', index_get_class_footer_articles(30,3));   // 调取关键词文章

$smarty->assign('youqinglianjie', get_link_footer(1));   // 调取友情链接

$smarty->assign('hezuowangzhan', get_link_footer(2));   // 调取合作网站

$smarty->assign('rementuijian', get_link_footer(3));   // 调取热门推荐

$get_index_banner=get_banner(2);

$index_banner = $get_index_banner[0];

$smarty->assign('index_banner',   $index_banner);           // 获取网站顶部banner

$get_custom_lunbo1=get_banner(90);

$custom_lunbo1 = $get_custom_lunbo1[0];

$smarty->assign('custom_lunbo1',   $custom_lunbo1);           // 获取个性定制轮播图1

$get_custom_lunbo2=get_banner(91);

$custom_lunbo2 = $get_custom_lunbo2[0];

$smarty->assign('custom_lunbo2',   $custom_lunbo2);           // 获取个性定制轮播图2

$get_custom_lunbo3=get_banner(92);

$custom_lunbo3 = $get_custom_lunbo3[0];

$smarty->assign('custom_lunbo3',   $custom_lunbo3);           // 获取个性定制轮播图3



$smarty->display('custom_gx_list.dwt');

//获取经典定制

function get_jingdiandingzhi($cat_id)

{

$sql = "SELECT * FROM " .$GLOBALS['ecs']->table('custom_gx'). " where cat_id = $cat_id AND is_best = 1   ORDER BY id DESC LIMIT 0,3" ;

$res = $GLOBALS['db']->getAll($sql);

$arr = array();

foreach ($res AS $idx => $row)

{

$arr[$idx]['title'] = $row['title'];

$arr[$idx]['id'] = $row['id'];

}

return $arr;

}

?>
