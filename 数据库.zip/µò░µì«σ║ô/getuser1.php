<?php
header("Content-type:text/html;charset=utf-8");
$q=$_GET["q"];
$id = $_GET['id'];


$con = mysql_connect('localhost','root','67dhytpc');
if (!$con)
{
die('Could not connect: ' . mysql_error($con));
}
mysql_select_db("yuanhe",$con);
mysql_query("set names utf8");



$sql="SELECT * FROM ecs_custom_gx WHERE style_id = '".$q."' ";
$result = mysql_query($sql,$con);
echo "<dl>";
while($row = mysql_fetch_array($result))
{
 echo "<dt>";
          echo '<div  style="width:248px;height:186px;">';
           echo '<a href="custom_detail.php?id='.$row['id'].'"  target="_blank" >';
           echo  '<img style="width:248px;height:186px;" src="./data/custom_gx_fmimg/'.$row['fmimg'].'"  />';
            echo "</a>";
           echo "</div>";
          echo  '<div class="xz_wenzi">'.$row['title'].'</div>';
           echo  '<div class="ty_btn">';
            echo '<a href="custom_detail.php?id='.$row['id'].'" target="_blank">';
           echo  '<img src="themes/default/images/customty.gif" width="91" height="21" />';
           echo  "</a>";
             echo  "</div>";
echo "</dt>";

// echo "<tr>";
// echo "<td>" . $row['title'] . "</td>";
// echo "<td>" . $row['fmimg'] . "</td>";
// echo "<td>" . $row['id'] . "</td>";

//echo "<td>  <img  src="./data/custom_gx_fmimg/ " . $row['fmimg'] .  "</td>";
// echo '<td> <img src="./data/custom_gx_fmimg/'.$row['fmimg'].'" /></td>';

// echo "</tr>";
}
echo "</dl>";

mysql_close($con);

?>
