<?php
header("Content-type:text/html;charset=utf-8");
//$q=$_GET["q"];
$con = mysql_connect('localhost','root','67dhytpc');
if (!$con)
{
die('Could not connect: ' . mysql_error($con));
}

$db_selected = mysql_select_db("yuanhe", $con);

if (!$db_selected)
  {
  die ("Can\'t use test_db : " . mysql_error());
  }

 $sql="SELECT * FROM ecs_crowd" ;
 $query=mysql_query($sql,$con);
 print_r(mysql_fetch_assoc($query));
 //var_dump($query);
// print_r($result);我们的test

// print_r(mysqli_fetch_array($result));

mysql_close($con);

?>
